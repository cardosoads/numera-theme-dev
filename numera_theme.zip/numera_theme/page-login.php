<?php

/* Template Name: Login Page */

// Custom redirect after login
define('CUSTOM_LOGIN_TEMPLATE_LOADED', true);
function custom_login_redirect($redirect_to, $request, $user) {
    if (isset($user->roles) && is_array($user->roles)) {
        if (in_array('administrator', $user->roles)) {
            return admin_url();
        }
        return site_url('/dashboard');
    }
    return $redirect_to;
}
add_filter('login_redirect', 'custom_login_redirect', 10, 3);

// Handle failed login without redirecting to wp-login.php
function custom_login_failed_redirect($username) {
    $referrer = wp_get_referer();
    if ($referrer && !strstr($referrer, 'wp-login.php')) {
        wp_redirect(add_query_arg('login', 'failed', $referrer));
        exit;
    }
}
add_action('wp_login_failed', 'custom_login_failed_redirect');


?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <style>
        .modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 40; }
        .modal { display: none; position: fixed; inset: 0; overflow-y: auto; z-index: 50; }
    </style>
</head>
<body <?php body_class(); ?>>

<div class="min-h-screen flex">
    <div class="w-full md:w-1/2 bg-[#F8DDE1] flex flex-col justify-center items-center p-8">
        <h2 class="text-2xl font-bold mb-6">Login</h2>
        <form id="login-form" method="post" action="<?php echo esc_url(wp_login_url()); ?>" class="w-full max-w-md">
            <div class="mb-4">
                <label for="user_login" class="block text-sm font-medium text-gray-700">Usuário ou E-mail</label>
                <input type="text" name="log" id="user_login" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div class="mb-6">
                <label for="user_pass" class="block text-sm font-medium text-gray-700">Senha</label>
                <input type="password" name="pwd" id="user_pass" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
            </div>
            <div class="mb-4">
                <input type="hidden" name="redirect_to" value="<?php echo esc_url(site_url('/')); ?>">
                <input type="submit" name="wp-submit" value="Login" class="w-full bg-[#42275C] text-white py-2 px-4 rounded-md hover:bg-[#633A8A] focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
            </div>
        </form>
        <div class="w-full max-w-md text-center">
            <button id="open-recover" class="text-sm text-indigo-600 hover:underline focus:outline-none">Esqueceu a senha?</button>
        </div>
        <?php if (isset($_GET['login']) && $_GET['login'] == 'failed'): ?>
            <p class="mt-4 text-red-500">Erro: Nome de usuário ou senha incorretos.</p>
        <?php endif; ?>
    </div>
    <div class="flex bg-[#E2CBEA] bg-contain md:w-1/2 justify-center items-center">
        <img class="w-[400px] h-auto" src="<?php echo get_template_directory_uri() . '/images/logo.png'; ?>" alt="Logo">
    </div>
</div>

<!-- Modal backdrop -->
<div class="modal-backdrop" id="modal-backdrop"></div>

<!-- Modal container -->
<div class="modal flex content-center" id="recover-modal">
  <div class="modal-content bg-white rounded-2xl p-6 max-w-sm mx-auto shadow-lg relative">
    <!-- Botão fechar -->
    <button id="modal-close-btn" class="absolute top-3 right-3 text-gray-500 hover:text-gray-800">
      &times;
    </button>

    <h3 class="text-xl font-semibold mb-4">Recuperar Senha</h3>
    <p class="text-sm mb-4">Digite seu e-mail para receber o link de recuperação:</p>
    <input type="email"
           id="recover-email"
           placeholder="seu@email.com"
           class="w-full mb-4 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 sm:text-sm">

    <div id="recover-msg" class="text-sm mb-4"></div>

    <div id="recover-actions" class="flex justify-end space-x-2">
      <button id="close-recover" class="px-4 py-2 rounded-md border focus:outline-none">Cancelar</button>
      <button id="submit-recover" class="px-4 py-2 bg-[#42275C] text-white rounded-md hover:bg-[#633A8A] focus:outline-none">Enviar</button>
    </div>
  </div>
</div>


<?php wp_footer(); ?>
</body>
</html>